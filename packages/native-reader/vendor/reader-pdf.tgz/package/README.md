# @hamster-note/reader

React reader component package for Hamster Note.

## 安装

Install the package and its peer dependencies:

```bash
yarn add @hamster-note/reader react react-dom
```

## 使用

Styles are not injected automatically. Import `@hamster-note/reader/style.css` explicitly before rendering `Reader`.

```tsx
import { Reader } from '@hamster-note/reader'
import type { ReaderProps } from '@hamster-note/reader'
import '@hamster-note/reader/style.css'

const document: NonNullable<ReaderProps['document']> = {
  id: 'demo-document',
  title: 'Hello Hamster',
  pages: []
}

export function App() {
  return <Reader document={document} emptyText='No document' />
}
```

### How It Works

The existing `document` API is parser-agnostic. It accepts an intermediate document (produced by parser packages such as `@hamster-note/pdf-parser`, `@hamster-note/docx-parser`, etc.) and renders it through the intermediate-document renderer. Layout pages use VirtualPaper reading mode by default, with contain mode disabled for continuous document navigation.

The renderer lazily loads page content on demand via a visibility-debounced queue with concurrency control and offscreen-release, designed for long documents without blocking the main thread.

#### Local PDF and EPUB source

The new `source` API accepts a stable `PdfSource` object containing owned-by-host
`Uint8Array` bytes (`{ kind: 'bytes', bytes }`) or a local blob URI
(`{ kind: 'uri', uri }`). Keep the object stable until replacing the document.
PDF signature detection ignores filename/MIME hints and selects an independent
PDF.js renderer. EPUB sources use the existing EPUB parser/viewer. Remote HTTP(S)
sources are rejected without requests. Supplying both `source` and `document`
reports `CONFLICTING_READER_INPUT` before reading either input.

Stage the exact package's worker, cMaps, fonts, WASM and ICC assets into the
consumer's public directory before building it:

```sh
node node_modules/@hamster-note/reader/dist/sync-pdf-runtime.mjs --target public
```

Import `@hamster-note/reader/style.css` as above, then render:

```tsx
<Reader
  source={source}
  pdfAssetBaseUrl={new URL('/pdf-runtime/', window.location.origin).href}
  onStateChange={(state) => console.log(state.status)}
  onPdfPageChange={(page) => console.log(page.pageNumber, page.pageCount)}
/>
```

The optional `pdfAssetBaseUrl` defaults to `/pdf-runtime/` on the page's origin;
use an explicit same-origin directory ending in `/` for subdirectory deployments.
The sync command validates all 198 assets against the bundled SHA-256 manifest.
PDF.js and its worker are pinned to 5.4.530; do not substitute a CDN worker.
`@hamster-note/reader/pdf-dom` exposes the DOM adapter and
`@hamster-note/reader/pdf-contracts` exposes DOM-free types for platform hosts.

PDF Pages uses physical 1-based page numbers and lazy thumbnails. Canvas/text
surfaces are limited to five, with two simultaneous main renders, two thumbnail
renders and a 32-entry thumbnail cache. PDF text selection shows a temporary
Popover with only a no-op “高亮” button; it does not call `onDataChange`, storage,
annotation history or undo. Scanned pages have no OCR. Password-protected PDFs
report a categorized error without prompting. Document scripts, XFA, eval and
external actions are not enabled. Context-menu suppression is scoped to the PDF
surface. Clearing/changing source releases reader resources without revoking
host blob URLs or modifying host bytes. `ready` requires a displayed page.

The legacy `document`/`data` API retains its existing annotation capabilities;
it does not reconstruct a PDF source. Roll back by restoring the previous
package and its paired assets, or stop supplying `source`. No saved-data
migration is needed. Main demo uploads use the source renderer for PDF,
including misleading filenames. Non-PDF uploads retain the existing parser;
`LegacyPdfDemo` is an explicit regression harness for the old PDF document API.

This change supplies the DOM renderer and neutral contracts. Native-reader's
separate Web iframe consumes an integrity-pinned npm artifact; native iOS
PDFKit and Android secure-WebView hosts remain pending. Native input keeps its
32 MiB bound; no npm release or device/menu acceptance is claimed here.

PDF browser tests include Chromium, Firefox and rootless Noble WebKit. For a
machine with the documented Podman image and Node 24, run
`yarn test:pdf:webkit --install` once, then `yarn test:pdf:webkit`.
Environment prerequisites, exact versions and the native-reader command are
recorded in `openspec/changes/add-platform-pdf-renderers/implementation-notes.md`.
Playwright WebKit is not actual Safari or mobile long-press/handles evidence.

#### Unified Reader data

Use `data` as the single persistence-friendly entry point for page crop, hidden pages, text and rectangle highlights, page drawings, the last VirtualPaper position/scale, and bookmarks. A field supplied through `data` takes precedence over its legacy flat prop; the flat props remain supported for compatibility.

```tsx
import { Reader } from '@hamster-note/reader'
import type { ReaderData } from '@hamster-note/reader'
import { useState } from 'react'

export function PersistedReader() {
  const [data, setData] = useState<ReaderData>({
    edgeCrop: {
      // Ratios use the original page size and may differ on every edge.
      all: { top: 0.05, right: 0.08, bottom: 0.04, left: 0.08 },
      // A page-specific crop replaces, rather than adds to, the global crop.
      pages: {
        'page-3': { top: 0.12, right: 0.03, bottom: 0.1, left: 0.03 }
      }
    },
    // Numbers are 1-based page numbers; strings are public page IDs.
    hiddenPages: [2, 'page-7'],
    ranges: [],
    rects: [],
    pagePaintings: {},
    virtualPaper: { x: 0, y: 0, scale: 1 },
    bookmarks: [
      {
        pageNumber: 1,
        textId: 'page-1-introduction',
        text: 'Introduction',
        offset: 0
      }
    ]
  })

  return (
    <Reader
      document={document}
      data={data}
      // Fired after a VirtualPaper pan/zoom gesture ends.
      onDataChange={setData}
      onSelect={(range) =>
        setData((current) => ({
          ...current,
          ranges: [...(current.ranges ?? []), range]
        }))
      }
      onPagePaintingsChange={(pagePaintings) =>
        setData((current) => ({ ...current, pagePaintings }))
      }
    />
  )
}
```

`edgeCrop` ratios are clamped to the valid page area. `edgeCrop.all` applies globally, while `edgeCrop.pages['page-N']` fully overrides it for that page. Visual edge crop is layout-mode only; `hiddenPages` applies to both layout and text modes. Invalid hidden-page values are ignored. Public page IDs always use `page-${pageNumber}`.

`onDataChange` reports the final VirtualPaper Layout position as `{ x, y, scale, anchor? }`, the native Layout viewport position through `data.layoutReadingProgress`, and the Text position as `{ currentPageNumber, anchor? }` through `data.textReadingProgress`. Native Layout progress stores the concrete text crossing the top of the viewport when available and falls back to `{ pageNumber, verticalPercentage }` for pages without text. A text anchor stores `{ pageNumber, textId, text, offset }`; `offset` is the target text's character offset within that page, not within the whole document. Restoration uses `textId` first and falls back to the page-local `offset` when that ID no longer exists. The legacy shapes without `anchor` remain valid and restore by transform or page number.

Pass the saved `ReaderData` back to restore either reading position. Precise bookmark toggles are merged into `data.bookmarks` through the same `onDataChange` callback. Highlight, rectangle, and drawing edits continue to use their existing typed callbacks. The deprecated `bookmarkedPageNumbers` and `onTogglePageBookmark` APIs remain available for hosts that still use page-only bookmarks.

#### Lazy Page Loading Props

The following optional props control the lazy loading queue:

| Prop                   | Type     | Default | Description                                                                                                                                                                  |
| ---------------------- | -------- | ------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `initialLoadedPages`   | `number` | `1`     | Number of pages to load immediately on mount (before visibility-based queue kicks in).                                                                                       |
| `pageLoadConcurrency`  | `number` | `3`     | Maximum number of pages loaded concurrently.                                                                                                                                 |
| `pageLoadEnterDelayMs` | `number` | `500`   | A non-initial page must remain continuously visible for this duration (ms) before its content load is enqueued. Prevents fast-scroll from triggering loads.                  |
| `pagePreloadRadius`    | `number` | `3`     | Number of adjacent pages to preload on each side of every visible page. The window is clipped safely at the beginning and end of the document.                            |
| `pageUnloadDelayMs`    | `number` | `5000`  | After a loaded page leaves the visible window, wait this duration (ms) before unloading its content back to an empty shell. Re-entering before the delay cancels the unload. |

#### Render Timing

To diagnose bottlenecks in the render pipeline, you can opt in to stage-by-stage timing logs. Production builds emit **no timing output by default**.

**Activation paths:**

1. **Callback prop** — receive every timing entry in code:

   ```tsx
   <Reader
     document={document}
     onIntermediateDocumentRenderTiming={(entry) => {
       console.table(entry)
     }}
   />
   ```

2. **Environment flag** — print `console.debug` logs when no callback is provided:
   ```bash
   VITE_HAMSTER_READER_INTERMEDIATE_TIMING=true
   ```

Each entry has the following shape:

| Field        | Type                  | Description                                                                                                                                                                               |
| ------------ | --------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `stage`      | `string`              | One of `document-resolution`, `shell-rendering`, `initial-page-loading`, `content-extraction`, `page-content-rendering`, `visibility-lazy-loading`, `offscreen-unload`, `ocr-processing`. |
| `startedAt`  | `number`              | Start timestamp (ms).                                                                                                                                                                     |
| `endedAt`    | `number`              | End timestamp (ms).                                                                                                                                                                       |
| `durationMs` | `number`              | `endedAt - startedAt`.                                                                                                                                                                    |
| `pageNumber` | `number` _(optional)_ | Present for page-scoped stages.                                                                                                                                                           |
| `detail`     | `object` _(optional)_ | Stage-specific context such as `pageCount`, `textCount`, `imageCount`, or `status`.                                                                                                       |

#### Demo Upload Formats

The browser Demo supports uploading and previewing the following formats:

- **PDF** (`.pdf`)
- **TXT** (`.txt`)
- **DOCX** (`.docx`)
- **EPUB** (`.epub`)
- **Markdown** (`.md`, `.markdown`)
- **Images** (`.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`, `.bmp`, `.svg`)

EPUB support uses `@hamster-note/epub-parser`. Both Layout and Text modes render the EPUB cover and embedded chapter images; reflowable EPUB pages still follow the parser's flow layout rather than fixed-layout fidelity.

## API Notes

### OCR

The default Reader toolbar includes an OCR toggle that starts off. Turn it on to recognize every loaded page immediately and automatically recognize pages loaded afterward. Hosts can control the same behavior with the `ocr` prop and `onOcrChange`, and listen for text selection updates with `onTextSelectionChange` and `onTextSelectionEnd`.

```tsx
<Reader
  document={document}
  ocr
  onTextSelectionChange={(text, detail) => {
    // handle selection change
  }}
  onTextSelectionEnd={(text, detail) => {
    // handle selection end
  }}
/>
```

`ocr` accepts two shapes:

| Value                             | Behavior                                                                                                                                                                                                 |
| --------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `true` / `{ enabled: true }`      | Auto mode: OCR runs for every currently loaded page and each page loaded afterward.                                                                                                                      |
| `{ enabled: true, pages: [...] }` | Manual mode: only the listed page numbers (1-based) are recognized and displayed. Removing a page from the list closes OCR for that page (in-flight results are discarded and the cache is invalidated). |
| `false` / `{ enabled: false }`    | Global off: all OCR text layers are cleared for the current document.                                                                                                                                    |

Recognized text is rendered as a transparent, selectable text layer on top of the page image. While a page is being recognized, the page shows an in-page loading badge that disappears on success or failure.

OCR always runs on the original-size page image (`IntermediatePage.getThumbnail(1)`), re-requested from the parser — never on the zoom-dependent display thumbnail. Recognition resolution is therefore stable across zoom levels, and the returned polygons align with the page coordinate space. Pages whose only image is an inline `thumbnail`/`image` property fall back to that inline image.

OCR results can be controlled by the host to avoid repeated recognition (for example, when restoring persisted data):

| Prop               | Type                                                                     | Description                                                                                                                                                                                                                                           |
| ------------------ | ------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `extraOCR`         | `(imageBase64: string) => IntermediatePage \| Promise<IntermediatePage>` | Optional external OCR provider. It receives the original-size page image and replaces the built-in image parser for recognition. Defaults to `undefined`.                                                                                             |
| `onOcrChange`      | `(enabled: boolean) => void`                                              | Fired when the default toolbar OCR toggle changes. When `ocr` is controlled, update the host value from this callback.                                                                                                                                |
| `ocrTexts`         | `Readonly<Record<number, readonly IntermediateText[]>>`                  | Controlled OCR text per page (1-based). Pages with data are rendered directly and never re-recognized; in manual mode only pages listed in `ocr.pages` are displayed.                                                                                 |
| `onOcrTextsChange` | `(pageNumber: number, texts: IntermediateText[]) => void`                | Fired when a page finishes OCR. Persist the result and pass it back via `ocrTexts`.                                                                                                                                                                   |
| `onOcrError`       | `(error: unknown, detail: { pageNumber: number }) => void`               | Fired when a page's OCR fails. A failed page is not retried until it is closed and reopened.                                                                                                                                                          |
| `ocrDebug`         | `boolean`                                                                | Dev/debug mode: OCR text is rendered visibly (black at 50% opacity) with a red outline instead of transparent, so you can verify recognition position and content. Rendering-only; stored/`onOcrTextsChange` data is unaffected. Defaults to `false`. |

```tsx
const [ocrPages, setOcrPages] = useState<number[]>([])
const [ocrTexts, setOcrTexts] = useState<Record<number, IntermediateText[]>>({})

<Reader
  document={document}
  ocr={{ enabled: true, pages: ocrPages }}
  extraOCR={async (imageBase64) => externalOcrService.recognize(imageBase64)}
  ocrTexts={ocrTexts}
  onOcrTextsChange={(pageNumber, texts) =>
    setOcrTexts((current) => ({ ...current, [pageNumber]: texts }))
  }
/>
```

### Text render mode

`Reader` uses `renderMode='layout'` by default. Set `renderMode='text'` to render a flow reading view that mounts and loads only the virtual pages currently visible in the scroll viewport.

Text mode renders document text and content-level `IntermediateImage` entries as normal flow content. Each image occupies its own row, and an available image `alt` value is shown as both accessible alternative text and a visible caption. Page base images, thumbnails, and OCR output are not rendered in Text mode. It uses the same linked ranges as layout mode, but derives current text-flow rectangles from each range's `selectionId + offset` anchors instead of rendering the persisted layout rectangles.

`containMarginX`, `containMarginTop`, and `containMarginBottom` apply directly to the Text-mode scroll viewport in screen pixels. `showPageBrowser` also works in Text mode, but exposes only the highlight and bookmark tabs; the unavailable page-preview tab is not rendered. Store `data.textReadingProgress` from `onDataChange` to restore the exact text at the top of the viewport after reopening a document.

### Dark mode

Pass `darkMode` to theme Reader content together with its built-in bottom toolbar and built-in selection, highlight, and rectangle popovers. In Layout mode the article is directly inverted while embedded images, canvases, videos, and SVG images are inverted a second time to preserve their source colors. Text mode uses black surfaces and white text without filtering images.

```tsx
<Reader document={document} darkMode={darkMode} />
```

`darkMode={true}` enables the complete dark theme, while `darkMode={false}` explicitly selects light content and chrome. Omitting the prop preserves compatibility with earlier releases: article content stays light, the built-in toolbar follows the operating-system color preference, and the built-in popovers retain their original dark appearance. Custom `bottomBar`, `selectionPopover`, `highlightPopover`, and `rectPopover` content remains responsible for its own theme.

### Text, rectangle, and drawing tools

In layout mode, `selectedTool` switches the active page interaction without replacing the virtualized reader. Existing zoom, page-range, OCR, lazy loading, and linked-selection behavior therefore remains available in every tool mode.

For documents with pages, `Reader` renders a built-in bottom toolbar by default. It includes undo/redo, Layout/Text mode, touch pan, edge crop, selection tools, drawing/highlight colors, and the font-scale menu when `fontScale` is provided. When drawing is active, the same bottom-bar area also renders `@hamster-note/painting`'s controlled painting tools, so every page shares the selected drawing tool, stroke color, width, and related options. Omit the value props to let Reader manage toolbar state internally, or pair them with their `on...Change` callbacks for controlled state.

Pass a React node through `bottomBar` to replace the built-in toolbar. Pass `bottomBar={null}` to disable it explicitly.

```tsx
const [selectedTool, setSelectedTool] = useState<ReaderPageTool>('text-selection')
const [pagePaintings, setPagePaintings] = useState<ReaderPagePaintingMap>({})

<Reader
  document={document}
  selectedTool={selectedTool}
  pagePaintings={pagePaintings}
  onPagePaintingsChange={setPagePaintings}
/>
```

- `text-selection` uses the same linked ranges in layout and text modes (`ranges`, `onHighlight`, `onUpdateRange`).
- `rect-selection` uses the existing rectangle API (`rects`, `onCreateRect`, `onUpdateRect`).
- `drawing` enables a per-page `PaintingBoard` with its internal toolbar disabled. Reader renders the shared `PaintingController` in its own bottom-bar area; `paintingTool` / `onPaintingToolChange` and `drawingStrokeColor` / `onDrawingStrokeColorChange` can control its tool and color. Painting map keys use stable public IDs such as `page-1` and `page-2`.
- An explicitly supplied legacy `tool` prop takes precedence over the text/rectangle mapping from `selectedTool`.
- `renderMode='text'` remains text-only and does not mount drawing or rectangle overlays.

## Text Selection (@hamster-note/selection)

`Reader` integrates [`@hamster-note/selection`](https://www.npmjs.com/package/@hamster-note/selection) to provide rich text-selection features, highlighted ranges, popovers, and programmatic control on top of the native browser `Selection` API.

The `<Selection>` component wraps page content inside `<VirtualPaper>` and is active by default. The legacy native callbacks (`onTextSelectionChange`, `onTextSelectionEnd`, `onSelectText`) continue to fire alongside the linked-range Selection component.

### Canonical linked range shape

Both render modes persist the Layout-compatible linked range shape. Each endpoint carries a public page `selectionId`, and overlay rectangles are grouped by that page id in `rectsBySelectionId`.

```ts
{
  id: 'highlight-1',
  text: 'Selected text',
  start: { selectionId: 'page-1', offset: 12 },
  end: { selectionId: 'page-2', offset: 34 },
  createdAt: Date.now(),
  overlayRectType: 'percent',
  rectsBySelectionId: {
    'page-1': [{ x: 0.1, y: 0.2, width: 0.5, height: 0.05 }],
    'page-2': [{ x: 0.05, y: 0.1, width: 0.4, height: 0.05 }]
  }
}
```

Public page ids are always `page-${pageNumber}` (for example, `page-1`, `page-2`). Internally, each `Reader` instance scopes runtime Selection ids so two Readers on the same page cannot collide, but public callbacks and stored data stay unscoped. You should only read and write the public `page-${pageNumber}` ids.

### Text-mode highlight geometry

`ReaderSelectionRange` is the only persisted highlight shape in both render modes. In text mode, `start.selectionId + start.offset` and `end.selectionId + end.offset` act as stable character anchors. The mounted text pages derive runtime rectangles again whenever font scale, line wrapping, page content, or container size changes. Persisted `rectsBySelectionId` remains available to layout mode and is never treated as current text-flow geometry.

### Quick Start (linked selection)

```tsx
import { Reader } from '@hamster-note/reader'
import type { ReaderSelectionRange } from '@hamster-note/reader'
import '@hamster-note/reader/style.css' // includes Selection CSS
import { useState } from 'react'

const initialRanges: ReaderSelectionRange[] = [
  {
    id: 'highlight-1',
    text: 'Selected text on page 1',
    start: { selectionId: 'page-1', offset: 12 },
    end: { selectionId: 'page-1', offset: 34 },
    createdAt: Date.now(),
    overlayRectType: 'percent',
    rectsBySelectionId: {
      'page-1': [{ x: 0.1, y: 0.2, width: 0.5, height: 0.05 }]
    }
  }
]

export function App() {
  // 受控模式：Reader 不内部修改 ranges，由 onSelect 回调外部追加
  const [ranges, setRanges] = useState<ReaderSelectionRange[]>(initialRanges)

  return (
    <Reader
      document={document}
      ranges={ranges}
      overlayRectType='percent'
      onSelect={(range) => setRanges((prev) => [...prev, range])}
      onUpdateRange={(range) =>
        setRanges((prev) => prev.map((r) => (r.id === range.id ? range : r)))
      }
    />
  )
}
```

### Props

| Prop                     | Type                                                                        | Description                                                                                                                                                                                                |
| ------------------------ | --------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ranges`                 | `ReaderSelectionRange[]`                                                    | Controlled highlight ranges in the linked shape. Reader does not mutate this array.                                                                                                                        |
| `defaultRanges`          | `ReaderSelectionRange[]`                                                    | Initial ranges for uncontrolled mode (when `ranges` is omitted).                                                                                                                                           |
| `selectedRangeId`        | `string \| null`                                                            | Controlled currently-selected range ID.                                                                                                                                                                    |
| `defaultSelectedRangeId` | `string \| null`                                                            | Initial selected range ID for uncontrolled mode.                                                                                                                                                           |
| `onSelect`               | `(range: ReaderSelectionRange) => void`                                     | Fired when the user finishes a new selection. In uncontrolled mode, Reader appends the range internally before calling this.                                                                               |
| `onSelectRange`          | `(id: string \| null) => void`                                              | Fired when the user clicks an existing highlight.                                                                                                                                                          |
| `onUpdateRange`          | `(range: ReaderSelectionRange) => void`                                     | Fired when the user drags a selected highlight range handle. In uncontrolled mode, Reader replaces the matching range internally before calling this; controlled callers must update their `ranges` array. |
| `onHighlight`            | `(range: ReaderSelectionRange) => void`                                     | Fired when a range is highlighted via the ref API or via Reader's internal auto-highlight (when `autoHighlight` is enabled).                                                                               |
| `onDragHighlight`        | `(highlight: ReaderSelectionRange) => void`                                 | Fired once when primary-button mouse movement over an existing highlight exceeds 4px, or when a stationary primary touch is held for 500ms. The callback receives the original public range object.        |
| `onSelectionStart`       | `(mousePos: ReaderMousePosition, selection: Selection) => void`             | Fired when a selection gesture begins.                                                                                                                                                                     |
| `onSelectionEnd`         | `(mousePos: ReaderMousePosition, selection: Selection) => void`             | Fired when a selection gesture ends (mouseup-based; touch selection may not trigger this).                                                                                                                 |
| `autoHighlight`          | `boolean`                                                                   | When true, completing a text selection automatically creates a highlight. Reader fires `onHighlight` but does not append to ranges array. Defaults to `false`.                                             |
| `highlightColor`         | `string`                                                                    | Default CSS color for highlight overlays. A range-specific `markerStyle.backgroundColor` takes precedence.                                                                                                 |
| `selectionColor`         | `string`                                                                    | CSS color for the browser-native active text selection.                                                                                                                                                     |
| `showSelectionMagnifier` | `boolean`                                                                   | Enables Selection's built-in endpoint magnifier while dragging its built-in handles. Defaults to `true`.                                                                                                   |
| `selectionPopover`       | `React.ReactNode`                                                           | Custom popover content shown during active selection (before it becomes a highlight).                                                                                                                      |
| `highlightPopover`       | `React.ReactNode \| ((highlight: ReaderSelectionRange) => React.ReactNode)` | Custom popover content shown when an existing highlight is clicked. The renderer receives the original range object, so range-specific color and metadata can be displayed.                                |
| `onCommentHighlight`     | `(highlight: ReaderSelectionRange) => Promise<ReaderSelectionRange>`        | Adds a comment button to the existing-highlight popover. The callback receives the original range reference. Resolve with that same range when the host comment UI closes; Reader then closes the popover. |
| `selectionRef`           | `React.Ref<ReaderSelectionRef>`                                             | Reader-owned command ref, distinct from the upstream Selection component ref. Exposes `highlight()`, `clear()`, and additive `scrollToRange(id)` for jumping to an existing range.                         |
| `overlayRectType`        | `ReaderSelectionOverlayRectType`                                            | Controls whether selection overlay rectangles are stored/rendered as pixel (`'px'`) or percentage (`'percent'`) coordinates relative to the selection container. Defaults to `'percent'`.                  |
| `containMarginX`         | `number`                                                                    | Horizontal whitespace around the Layout virtual paper or Text scroll viewport.                                                                                                                            |
| `containMarginTop`       | `number`                                                                    | Independent top whitespace in screen pixels. It also positions the reading-progress rail.                                                                                                                 |
| `containMarginBottom`    | `number`                                                                    | Independent bottom whitespace in screen pixels. It also positions the reading-progress rail.                                                                                                              |
| `containMarginY`         | `number`                                                                    | Deprecated symmetric vertical whitespace fallback. It is ignored when either independent vertical margin is supplied.                                                                                      |
| `showPageBrowser`        | `boolean`                                                                   | Shows the left-side browser. Layout mode exposes page, highlight, and bookmark tabs; Text mode exposes only highlight and bookmark tabs. Layout thumbnails share the lazy-loading cache. Defaults to `false`. |

The existing-highlight popover can use range-specific data and delegate the comment lifecycle to the host:

```tsx
<Reader
  ranges={ranges}
  selectedRangeId={selectedRangeId}
  highlightPopover={(highlight) => (
    <input
      type='color'
      value={String(highlight.markerStyle?.backgroundColor ?? '#ffc107')}
    />
  )}
  onCommentHighlight={(highlight) =>
    new Promise((resolve) => {
      openCommentEditor(highlight, () => resolve(highlight))
    })
  }
/>
```

### Exported Types

```ts
import type {
  ReaderSelectionRange, // linked: { id, text, start, end, rectsBySelectionId, overlayRectType? }
  ReaderSelectionOverlayRectType, // 'px' | 'percent'
  ReaderSelectionRef, // { highlight(): void; clear(): void; scrollToRange(id: string): void }
  ReaderMousePosition // { x, y }, viewport coordinates (clientX/clientY)
} from '@hamster-note/reader'
```

### Touch pan mode

`Reader` uses single-finger document panning by default:

```tsx
<Reader document={document} touchPanMode='single-finger' />
```

Set `touchPanMode='two-finger'` when the host app needs one-finger touch gestures for something else. In this mode, one finger no longer moves the document, while two-finger pinch zoom and pinch movement keep the same behavior as the default layout reader.

This prop applies to layout mode only. `renderMode='text'` does not mount `VirtualPaper`, so touch pan mode has no effect there.

### CSS

`@hamster-note/reader/style.css` already bundles the Selection library CSS (`.hsn-selection-*` classes). No additional import is needed.

### Legacy Selection Callbacks

The existing `onTextSelectionChange`, `onTextSelectionEnd`, and `onSelectText` callbacks are preserved for backward compatibility. They continue to fire through the native `mouseup`/`touchend`/`selectionchange` listeners on the viewer root element, independent of the `<Selection>` component. They are not affected by the linked range shape.

> **Note**: `onSelectionEnd` is **mouseup-based**. On touch devices, the selection-end signal relies on the legacy `touchend` listener (which fires `onTextSelectionEnd` / `onSelectText`), not `onSelectionEnd`.

### Demo Browser Storage

The browser Demo persists annotation metadata to localStorage keyed by filename. Layout and text-mode annotations share `{ version: 4, ranges: ReaderSelectionRange[], rects: ReaderSelectionRectangle[], paintings: Record<string, DrawingValue> }` under `hamster-reader-demo:highlights:{filename}`. Layout reading progress is stored as a precise text anchor or `{ pageNumber, verticalPercentage }` fallback under `hamster-reader-demo:layout-reading-progress:{filename}`. Text reading progress is stored as `{ currentPageNumber, anchor? }` under `hamster-reader-demo:text-reading-progress:{filename}`, and precise `ReaderBookmark[]` anchors use `hamster-reader-demo:bookmarks:{filename}`. Comments are stored under `hamster-reader-demo:comments:{filename}` as `{ version: 2, comments: ReaderComment[] }`. On read, the Demo migrates legacy comment formats (`Record<highlightId, CommentItem[]>` and `Record<highlightId, string>`) into the version 2 shape. Older unversioned bare highlight arrays, or legacy objects with flat numeric `start`/`end` and `rects`, are ignored and return `[]`. Legacy numeric Demo bookmarks are also ignored because they do not contain a text ID, text, or page-local offset and therefore cannot be safely converted to a precise bookmark. The library-level deprecated page-number bookmark API remains compatible. If the Demo has old metadata that cannot prove its location, recreate that annotation or bookmark instead.

For legacy parser documents, the Demo stores the source `File` in browser-local IndexedDB after parsing. `LegacyPdfDemo` retains its two-phase PDF pending/load flow for compatibility tests. Default PDF uploads now open directly through the source renderer and keep only temporary reader state; they do not add PDF annotations or source persistence. The legacy Demo labels successful persistence beside uploaded-file details and provides a **Forget saved file** button. Clearing a saved legacy file does not dispose the document currently being read or delete its filename-keyed annotation metadata; use the browser's site-data controls to remove all legacy Demo storage.

### Programmatic Control

`selectionRef` exposes Reader-level commands. `highlight()` and `clear()` are forwarded to the active page Selection instances; `scrollToRange(id)` is implemented by Reader to translate the VirtualPaper viewport to an existing range while preserving the current scale.

```tsx
import { useRef } from 'react'
import type { ReaderSelectionRef } from '@hamster-note/reader'

const selectionRef = useRef<ReaderSelectionRef>(null)

// Highlight the current native selection as a range
selectionRef.current?.highlight()

// Clear all highlights
selectionRef.current?.clear()

// Scroll the viewer to a specific range by id
selectionRef.current?.scrollToRange('highlight-1')
```

## Comments

`Reader` exposes a purely controlled comments API. There is no `defaultComments` prop and no uncontrolled mode: the host owns the comment list and `Reader` never mutates it. The library ships no comment UI; the host owns presentation (panel, editor, badges). The existing `onCommentHighlight` prop is unchanged and remains the popover 评论 entry point for creating a comment from a highlight.

```ts
type ReaderComment = {
  id: string
  highlightIds: readonly string[] // one comment can bind multiple highlights (M:N)
  content: string
  createdAt: number
  updatedAt?: number
  parentId: string | null // null for root comments; set for replies
}
```

### Props

| Prop               | Type                                                                          | Description                                                                                     |
| ------------------ | ----------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| `comments`         | `readonly ReaderComment[]`                                                    | Controlled comment list. Reader does not mutate this array.                                     |
| `onCommentsChange` | `(next: readonly ReaderComment[], detail: ReaderCommentChangeDetail) => void` | Fired with the next comment list and a change detail. The host applies `next` to its own state. |

`detail.source` is one of `'add'`, `'reply'`, `'update'`, `'delete'`, `'bind-highlights'`, or `'external-sync'`. The detail may also carry `commentId`, `parentId`, and `highlightIds` for the affected entities.

```tsx
import { useState } from 'react'
import { Reader } from '@hamster-note/reader'
import type { ReaderComment } from '@hamster-note/reader'

export function App({ document }) {
  // 受控模式：Reader 不内部修改 comments，由 onCommentsChange 回调外部更新
  const [comments, setComments] = useState<readonly ReaderComment[]>([])

  return (
    <Reader
      document={document}
      comments={comments}
      onCommentsChange={(next) => setComments(next)}
    />
  )
}
```

### Helpers

The package exports pure helpers for deriving views over the comment list:

| Helper                         | Signature                                    | Description                                                                                                                                                          |
| ------------------------------ | -------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `getCommentsByHighlightId`     | `(comments, highlightId) => ReaderComment[]` | Comments bound to one highlight, ordered by `createdAt` (ties keep input order).                                                                                     |
| `getCommentCountByHighlightId` | `(comments) => Record<string, number>`       | Comment count per bound highlight ID. Binding is M:N, so one comment increments the count of every ID in its `highlightIds`; replies are counted too.                |
| `buildReaderCommentTree`       | `(comments) => ReaderCommentThreadNode[]`    | Builds a reply tree. A comment whose `parentId` is missing from the list is treated as a root. Roots and replies are ordered by `createdAt` (ties keep input order). |

`ReaderCommentThreadNode` is `ReaderComment` plus a recursive `replies: readonly ReaderCommentThreadNode[]`.

### Highlight badge counts

`IntermediateDocumentViewer` derives range badge counts as `commentCountByRangeId ?? (comments ? getCommentCountByHighlightId(comments) : undefined)`. An explicitly supplied `commentCountByRangeId` always wins. `commentCountByRectId` is never derived from `comments`.

### Undo/redo

Comments are excluded from `ReaderAnnotationHistoryValue`; undo/redo does not touch comments.

### Demo behavior

The browser Demo persists comments in localStorage (see Demo Browser Storage) and prunes bindings when a highlight is deleted: removing a highlight removes it from every comment's `highlightIds`, and comments left with zero bindings are deleted together with their reply subtree.

## Annotation History (undo/redo)

`Reader` can track undoable snapshots of annotation state. This is an opt-in feature; it is disabled by default.

The snapshot only includes text ranges, rectangle selections, and their active IDs:

```ts
{
  ranges: ReaderSelectionRange[]
  rects: ReaderSelectionRectangle[]
  selectedRangeId: string | null
  selectedRectId: string | null
}
```

Drawing state, `pagePaintings`, and comments are intentionally excluded and are not affected by undo/redo.

### Props

| Prop                        | Type                                                                                        | Default | Description                                                                     |
| --------------------------- | ------------------------------------------------------------------------------------------- | ------- | ------------------------------------------------------------------------------- |
| `annotationHistory`         | `boolean \| ReaderAnnotationHistoryOptions`                                                 | `false` | Enable annotation history. Passing `true` is equivalent to `{ enabled: true }`. |
| `onAnnotationHistoryChange` | `(next: ReaderAnnotationHistoryValue, detail: ReaderAnnotationHistoryChangeDetail) => void` | —       | Fired after the history present state changes. Required for controlled mode.    |

```ts
type ReaderAnnotationHistoryOptions = {
  enabled?: boolean
  resetKey?: string | number
}
```

`onAnnotationHistoryChange` receives the new snapshot and a detail object:

```ts
type ReaderAnnotationHistoryChangeDetail = {
  source: ReaderAnnotationHistoryChangeSource
  status: ReaderAnnotationHistoryStatus
}
```

`source` is one of:

- `'select'` — a new text range was selected
- `'highlight'` — a range was confirmed via the ref API or auto-highlight
- `'update-range'` — an existing range was updated (for example, by dragging a handle)
- `'create-rect'` — a new rectangle selection was created
- `'update-rect'` — an existing rectangle was updated
- `'clear'` — all annotations were cleared
- `'undo'` — the host or UI called `undo()`
- `'redo'` — the host or UI called `redo()`
- `'reset'` — history was reset, usually because `resetKey` changed
- `'external-sync'` — the snapshot was synced from an external controlled update

`status` contains:

```ts
{
  enabled: boolean
  canUndo: boolean
  canRedo: boolean
  pastCount: number
  futureCount: number
}
```

### Ref commands

When history is enabled, `selectionRef` exposes undo/redo commands:

| Command                       | Return                          | Description                                                                      |
| ----------------------------- | ------------------------------- | -------------------------------------------------------------------------------- |
| `undo()`                      | `boolean`                       | Reverts to the previous snapshot. Returns `false` when there is nothing to undo. |
| `redo()`                      | `boolean`                       | Reapplies the next snapshot. Returns `false` when there is nothing to redo.      |
| `canUndo()`                   | `boolean`                       | Whether at least one past snapshot exists.                                       |
| `canRedo()`                   | `boolean`                       | Whether at least one future snapshot exists.                                     |
| `getAnnotationHistoryState()` | `ReaderAnnotationHistoryStatus` | Returns the full status object.                                                  |

### `resetKey`

Use `resetKey` to clear the undo/redo stacks when the user opens a different file or document. This is safer than comparing `annotationHistory` props deeply because it keeps the prop reference stable and lets `Reader` reset history explicitly.

```tsx
<Reader
  document={document}
  annotationHistory={{ enabled: true, resetKey: document.id }}
/>
```

A change to `resetKey` drops `past` and `future`, sets `present` to the current ranges/rects/selections, and fires `onAnnotationHistoryChange` with source `'reset'`.

### Controlled mode

In controlled mode, the host keeps the `ranges` and `rects` state and echoes it back through props. `onAnnotationHistoryChange` is the canonical update path when history is enabled.

```tsx
import { useRef, useState } from 'react'
import { Reader } from '@hamster-note/reader'
import type {
  ReaderAnnotationHistoryValue,
  ReaderSelectionRange,
  ReaderSelectionRectangle,
  ReaderSelectionRef
} from '@hamster-note/reader'

export function App({ document }) {
  const selectionRef = useRef<ReaderSelectionRef>(null)
  const [ranges, setRanges] = useState<ReaderSelectionRange[]>([])
  const [rects, setRects] = useState<ReaderSelectionRectangle[]>([])

  return (
    <Reader
      document={document}
      ranges={ranges}
      rects={rects}
      annotationHistory={{ enabled: true, resetKey: document.id }}
      onAnnotationHistoryChange={(next: ReaderAnnotationHistoryValue) => {
        setRanges(next.ranges)
        setRects(next.rects)
      }}
    />
  )
}

// Later:
selectionRef.current?.undo()
selectionRef.current?.redo()
```

Undo and redo return `false` when `onAnnotationHistoryChange` is not provided, because `Reader` has no way to apply the recovered snapshot in controlled mode.

### Default toolbar and Demo shortcuts

Reader's built-in bottom toolbar always shows Undo and Redo buttons. Their disabled states follow Reader's internal annotation-history status; when annotation history is disabled, both commands remain disabled.

The browser Demo additionally attaches demo-only keyboard shortcuts:

- `Ctrl/Cmd+Z` — undo
- `Ctrl/Cmd+Shift+Z` or `Ctrl/Cmd+Y` — redo

These shortcuts are ignored when the active element is an `input`, `textarea`, or `[contenteditable]`, so they do not interfere with editable UI. These shortcuts are part of the Demo, not the library; hosts should wire their own shortcut logic and call `selectionRef.current?.undo()` / `redo()`.

## Peer Dependencies

- `react@^19.0.0`
- `react-dom@^19.0.0`

## 开发脚本

- `yarn dev`: start the local Vite dev server.
- `yarn build:lib`: build the library output in `dist/`.
- `yarn build:demo`: build the local demo output in `demo-dist/`.
- `yarn build:all`: build the library and demo.
- `yarn build`: run `yarn build:all`.
- `yarn typecheck`: run TypeScript type checking.
- `yarn lint`: run ESLint.
- `yarn test`: start Vitest in watch mode.
- `yarn test:run`: run Vitest once.
- `yarn preview`: preview the demo build.
- `yarn prepublishOnly`: build the library before publish.

## 发版规则

- Push a `vX.Y.Z` tag for stable releases.
- Push a `vX.Y.Z-<prerelease>` tag for pre-releases (e.g. `v1.0.0-beta`, `v1.0.0-dev`).
- Publish tag selection follows the package version suffix: no suffix -> `latest`, `-dev` -> `dev`, `-beta` -> `beta`.
